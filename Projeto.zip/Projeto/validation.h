#ifndef VALIDATION_H_INCLUDED
#define VALIDATION_H_INCLUDED
#include <stdbool.h>
#include <string.h>
#include <ctype.h>

bool is_number_digit_check(char key[]);


#endif // VALIDATION_H_INCLUDED
