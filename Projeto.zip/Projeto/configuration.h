#include <locale.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <stdbool.h>

const int REALLOCFACT;
const int ITEM_NAO_ENCONTRADO;

long rand_code();
void limpar();
void pausa();
void sair();
