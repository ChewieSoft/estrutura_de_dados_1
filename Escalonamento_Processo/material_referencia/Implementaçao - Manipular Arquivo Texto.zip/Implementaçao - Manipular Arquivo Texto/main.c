#include <stdio.h>
#include <stdlib.h>

/*Aula para manipula��o de arquivo texto*/

int main(int argc, char *argv[]) {
	FILE * arq;
	
	/*ABRIR ARQUIVO PARA ESCRITA*/	
	arq = fopen("teste.txt","w");
	/*"r" = abrir com permiss�o de leitura: � necess�rio que o arquivo j� exista
	  "w" = abrir com permiss�o de escrita: cria o arquivo se n�o existe e se existe ele ser� recriado
	  "a" = abrir para escrever no final (append) 
	*/
	if(arq == NULL){
		printf("\nErro ao abrir o arquivo!");
		exit(1);
	}
	
	/*ESCREVER NO ARQUIVO*/
	char palavra[20];
	int idade,qtd,i; 
	printf("\nInforme a quantidade de pessoas: ");
	scanf("%d",&qtd);
	for(i=0;i<qtd;i++){
		printf("\nInforme um nome: ");
		scanf("%s",palavra);
		printf("\nInforme a idade: ");
		scanf("%d",&idade);
		fprintf(arq,"%s %d",palavra,idade);
		if(i<qtd-1) //n�o � a ultima linha
			fprintf(arq,"\n");
			
	}	
	fclose(arq);
	
	//######################################################
	
	
	/*ABRIR ARQUIVO PARA LEITURA*/	
	arq = fopen("teste.txt","r");
	if(arq == NULL){
		printf("\nErro ao abrir o arquivo!");
		exit(1);
	}
	
	/*FORMA 1 DE LER DADOS DO ARQUIVO - Caracter a caracter*/
	printf("\n\nLeitura caracter a caracter\n");
	char c;
	do{
		c = getc(arq);
		printf("%c",c);
	}while(c!=EOF); //End of File
	fclose(arq);
	
	//#########################################################
	
	/*ABRIR ARQUIVO PARA LEITURA*/	
	arq = fopen("teste.txt","r");
	if(arq == NULL){
		printf("\nErro ao abrir o arquivo!");
		exit(1);
	}
	
	/*FORMA 2 de LER DADOS DO ARQUIVO - linha a linha*/
	char linha[40];
	printf("\n\nLeitura linha a linha\n");
	while(fgets(linha,40,arq)){
		printf("%s",linha);
	}
	fclose(arq);

	//#####################################################
	
	/*ABRIR ARQUIVO PARA APPEND*/	
	arq = fopen("teste.txt","a");
	if(arq == NULL){
		printf("\nErro ao abrir o arquivo!");
		exit(1);
	}
	
	/*INSERIR DADOS NO FINAL DO ARQUIVO*/
	printf("\nInforme um nome: ");
	scanf("%s",palavra);
	printf("\nInforme a idade: ");
	scanf("%d",&idade);
	fprintf(arq,"%s %d\n",palavra,idade);
	fclose(arq);
	
	/*LEITURA COM INDICA��O TIPO*/
	arq = fopen("teste2.txt","r");
	if(arq == NULL){
		printf("\nErro ao abrir o arquivo!");
		exit(1);
	}
	int x,y,z;
	fscanf(arq,"%d %d %d\n",&x,&y,&z);	
	printf("%d %d %d",x,y,z);
	fclose(arq);

	return 0;
}
